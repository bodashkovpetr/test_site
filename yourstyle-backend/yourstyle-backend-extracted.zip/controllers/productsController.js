const db = require('../config/database');

async function getAllProducts(req, res) {
  try {
    const { category } = req.query;
    
    let query = 'SELECT * FROM products';
    let params = [];
    
    if (category) {
      query += ' WHERE category = $1';
      params.push(category);
    }
    
    query += ' ORDER BY created_at DESC';
    
    const result = await db.query(query, params);
    
    res.json({
      success: true,
      data: result.rows,
    });
  } catch (error) {
    console.error('Get products error:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Failed to fetch products' 
    });
  }
}

async function getProductById(req, res) {
  try {
    const { id } = req.params;
    
    const result = await db.query(
      'SELECT * FROM products WHERE id = $1',
      [id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        error: 'Product not found' 
      });
    }
    
    res.json({
      success: true,
      data: result.rows[0],
    });
  } catch (error) {
    console.error('Get product error:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Failed to fetch product' 
    });
  }
}

async function searchProducts(req, res) {
  try {
    const { q } = req.query;
    
    if (!q) {
      return res.status(400).json({ 
        success: false, 
        error: 'Search query is required' 
      });
    }
    
    const searchTerm = `%${q.toLowerCase()}%`;
    
    const result = await db.query(
      `SELECT * FROM products 
       WHERE LOWER(name) LIKE $1 
       OR LOWER(description) LIKE $1 
       ORDER BY created_at DESC`,
      [searchTerm]
    );
    
    res.json({
      success: true,
      data: result.rows,
    });
  } catch (error) {
    console.error('Search products error:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Search failed' 
    });
  }
}

module.exports = {
  getAllProducts,
  getProductById,
  searchProducts,
};
