const db = require('../config/database');

async function createOrder(req, res) {
  const client = await db.pool.connect();
  
  try {
    await client.query('BEGIN');
    
    const userId = req.user.userId;
    
    const cartResult = await client.query(
      `SELECT 
        c.product_id,
        c.quantity,
        p.price_cents
      FROM cart c
      JOIN products p ON c.product_id = p.id
      WHERE c.user_id = $1`,
      [userId]
    );
    
    if (cartResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ 
        success: false, 
        error: 'Cart is empty' 
      });
    }
    
    const totalCents = cartResult.rows.reduce(
      (sum, item) => sum + (item.quantity * item.price_cents), 
      0
    );
    
    const orderResult = await client.query(
      `INSERT INTO orders (user_id, total_cents, status) 
       VALUES ($1, $2, 'pending') 
       RETURNING id, user_id, total_cents, status, created_at`,
      [userId, totalCents]
    );
    
    const order = orderResult.rows[0];
    
    for (const item of cartResult.rows) {
      await client.query(
        `INSERT INTO order_items (order_id, product_id, quantity, price_cents) 
         VALUES ($1, $2, $3, $4)`,
        [order.id, item.product_id, item.quantity, item.price_cents]
      );
    }
    
    await client.query('DELETE FROM cart WHERE user_id = $1', [userId]);
    
    await client.query('COMMIT');
    
    const orderDetailsResult = await client.query(
      `SELECT 
        oi.id,
        oi.product_id,
        oi.quantity,
        oi.price_cents,
        p.name,
        p.category,
        p.image_url,
        (oi.quantity * oi.price_cents) as line_total_cents
      FROM order_items oi
      JOIN products p ON oi.product_id = p.id
      WHERE oi.order_id = $1`,
      [order.id]
    );
    
    res.status(201).json({
      success: true,
      data: {
        order: {
          ...order,
          items: orderDetailsResult.rows,
        },
      },
    });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Create order error:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Failed to create order' 
    });
  } finally {
    client.release();
  }
}

async function getOrderHistory(req, res) {
  try {
    const userId = req.user.userId;
    
    const ordersResult = await db.query(
      `SELECT id, total_cents, status, created_at 
       FROM orders 
       WHERE user_id = $1 
       ORDER BY created_at DESC`,
      [userId]
    );
    
    const orders = await Promise.all(
      ordersResult.rows.map(async (order) => {
        const itemsResult = await db.query(
          `SELECT 
            oi.id,
            oi.product_id,
            oi.quantity,
            oi.price_cents,
            p.name,
            p.category,
            p.image_url,
            (oi.quantity * oi.price_cents) as line_total_cents
          FROM order_items oi
          JOIN products p ON oi.product_id = p.id
          WHERE oi.order_id = $1`,
          [order.id]
        );
        
        return {
          ...order,
          items: itemsResult.rows,
        };
      })
    );
    
    res.json({
      success: true,
      data: orders,
    });
  } catch (error) {
    console.error('Get order history error:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Failed to fetch order history' 
    });
  }
}

module.exports = {
  createOrder,
  getOrderHistory,
};
