const express = require('express');
const router = express.Router();
const authenticate = require('../middleware/auth');
const { 
  createOrder, 
  getOrderHistory 
} = require('../controllers/ordersController');

router.use(authenticate);

router.post('/', createOrder);
router.get('/', getOrderHistory);

module.exports = router;
